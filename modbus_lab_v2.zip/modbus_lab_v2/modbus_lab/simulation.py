from flask import Flask, render_template, jsonify
from pymodbus.client import ModbusTcpClient
from pymodbus.exceptions import ModbusException

app = Flask(__name__)
client = ModbusTcpClient("localhost", port=502)

@app.route("/")
def simulation():
    try:
        if not client.is_socket_open():
            client.connect()
        
        # Fetch initial data from Modbus
        temp_result = client.read_holding_registers(0, count=1)
        pressure_result = client.read_holding_registers(1, count=1)
        motor_result = client.read_coils(0, count=1)

        if temp_result.isError() or pressure_result.isError() or motor_result.isError():
            raise Exception("Error reading Modbus data.")

        temp = temp_result.registers[0]
        pressure = pressure_result.registers[0]
        motor_state = motor_result.bits[0]

        return render_template("simulation.html", temperature=temp, pressure=pressure, motor_state=motor_state)
    except Exception as e:
        return f"Error fetching Modbus data: {e}"

@app.route("/live_data", methods=["GET"])
def live_data():
    try:
        if not client.is_socket_open():
            client.connect()
        
        # Fetch live data from Modbus
        temp_result = client.read_holding_registers(0, count=1)
        pressure_result = client.read_holding_registers(1, count=1)
        motor_result = client.read_coils(0, count=1)

        if temp_result.isError() or pressure_result.isError() or motor_result.isError():
            raise Exception("Error reading Modbus data.")

        temp = temp_result.registers[0]
        pressure = pressure_result.registers[0]
        motor_state = motor_result.bits[0]

        return jsonify({"temperature": temp, "pressure": pressure, "motor_state": motor_state})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)

